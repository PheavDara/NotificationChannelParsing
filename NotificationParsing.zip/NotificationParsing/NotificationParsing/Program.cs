﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NotificationParsing
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the notification title:");
            string input = Console.ReadLine();

            string[] validTags = { "BE", "FE", "QA", "Urgent" };
            List<string> foundTags = new List<string>();

            Regex regex = new Regex(@"\[(.*?)\]");
            MatchCollection matches = regex.Matches(input);

            foreach (Match match in matches)
            {
                string tag = match.Groups[1].Value;
                if (validTags.Contains(tag))
                {
                    foundTags.Add(tag);
                }
            }

            if (foundTags.Count > 0)
            {
                Console.WriteLine($"Receive channels: {string.Join(", ", foundTags)}");
            }
            else
            {
                Console.WriteLine("No valid tags found.");
            }
        }
    }
}
